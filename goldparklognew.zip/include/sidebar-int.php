<div class="sidebar-blog-categories">
                            <ul>
                                <li> <a href="Fitness-Service-Intergrity-Assessment.php">Fitness for Service Assessments.</a> </li>
                                <li> <a href="Pipeline-Life-Extension.php">Pipeline Life Extension</a> </li>
                                <li> <a href="Inspection-Planning.php"> Inspection Planning </a> </li>
                                <li> <a href="Risk-Assessment.php"> Risk Assessment </a> </li>
                                <li> <a href="Integrity-Management.php"> Integrity Management</a> </li>
                                <li> <a href="Pipeline-Repairs-Remediation.php"> Pipeline Repairs/Remediation </a> </li>
                                <li> <a href="Failure-Analyses.php"> Failure Analyses </a> </li>
                                <li> <a href="Stress-Analyses-Fea.php"> Stress Analyses-Fea </a> </li>
                                <li> <a href="Reliability-Analyses.php"> Reliability Analyses</a> </li>
                                
                            </ul>
</div>
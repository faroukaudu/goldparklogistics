<?php

    include("include/header.php");
?>






<style>
    html {
	scroll-behavior: smooth;
}
</style>



        <div id="masterslider" class="master-slider ms-skin-default mb-0">
            <!-- first slide -->
            <div class="ms-slide">
                <!-- slide background -->
                <img src="masterslider/blank.gif" data-src="img/slider/slide01.jpg" alt="Strongest distribution network"/>

                <img class="ms-layer" src="masterslider/blank.gif" data-src="img/slider/slider-line.jpg" alt=""
                     style="left: 0; top: 310px;"
                     data-type="image"
                     data-effect="left(short)"
                     data-duration="300"
                     data-hide-effect="fade"
                     data-delay="0"
                     />

                <h2 class="ms-layer pi-caption01"
                    style="left: 0; top: 340px;"
                    data-type="text"
                    data-effect="left(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="300"
                    >
                    strong
                </h2>

                <h2 class="ms-layer pi-caption01"
                    style="left: 0; top: 400px;"
                    data-type="text"
                    data-effect="left(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="600"
                    >
                    logistics
                </h2>

                <h2 class="ms-layer pi-caption01"
                    style="left: 0; top: 460px;"
                    data-type="text"
                    data-effect="left(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="900"
                    >
                    network
                </h2>
            </div><!-- .ms-slide end -->

            <!-- slide 02 start -->
            <div class="ms-slide">
                <!-- slide background -->
                <img src="masterslider/blank.gif" data-src="img/slider/slide02.jpg" alt="International Air freight"/>

                <h2 class="ms-layer pi-caption01"
                    style="left: 70px; top: 390px; right: 10px;"
                    data-type="text"
                    data-effect="top(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="00"
                    >
                    CLEARING & FORWARDING
                </h2>

                <img class="ms-layer" src="masterslider/blank.gif" data-src="img/slider/slider-line.jpg" alt=""
                     style="left: 540px; top: 450px;"
                     data-type="image"
                     data-effect="bottom(short)"
                     data-duration="300"
                     data-hide-effect="fade"
                     data-delay="300"
                     />

                <p class="ms-layer pi-text"
                   style="left: 150px; top: 470px;"
                   data-type="text"
                   data-effect="top(short)"
                   data-duration="300"
                   data-hide-effect="fade"
                   data-delay="600"
                   >
                   Licensed & Experienced Customs Agents You Can Trust
                </p>
            </div><!-- .ms-slide end -->
            <!-- slide 04 start -->
            <div class="ms-slide">
                <!-- slide background -->
                <img src="masterslider/blank.gif" data-src="img/slider/slide04.jpg" alt="Worldwide freight services"/>

                <h2 class="ms-layer pi-caption01"
                    style="left: 388px; top: 390px;"
                    data-type="text"
                    data-effect="top(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="00"
                    >
                    Trucking
                </h2>

                <img class="ms-layer" src="masterslider/blank.gif" data-src="img/slider/slider-line.jpg" alt=""
                     style="left: 540px; top: 450px;"
                     data-type="image"
                     data-effect="bottom(short)"
                     data-duration="300"
                     data-hide-effect="fade"
                     data-delay="300"
                     />

                <p class="ms-layer pi-text"
                   style="left: 265px; top: 470px;"
                   data-type="text"
                   data-effect="top(short)"
                   data-duration="300"
                   data-hide-effect="fade"
                   data-delay="600"
                   >
                    Reliable, Tailored and Safe Haulage Services
                </p>
            </div><!-- .ms-slide slide04 end -->

            <!-- slide 03 start -->
            <div class="ms-slide">
                <!-- slide background -->
                <img src="masterslider/blank.gif" data-src="img/slider/slide03.jpg" alt="Worldwide freight services"/>

                <h2 class="ms-layer pi-caption01"
                    style="left: 258px; top: 390px;"
                    data-type="text"
                    data-effect="top(short)"
                    data-duration="300"
                    data-hide-effect="fade"
                    data-delay="0"
                    >
                    Warehousing
                </h2>

                <img class="ms-layer" src="masterslider/blank.gif" data-src="img/slider/slider-line.jpg" alt=""
                     style="left: 540px; top: 450px;"
                     data-type="image"
                     data-effect="bottom(short)"
                     data-duration="300"
                     data-hide-effect="fade"
                     data-delay="300"
                     />

                <p class="ms-layer pi-text"
                   style="left: 170px; top: 470px;"
                   data-type="text"
                   data-effect="top(short)"
                   data-duration="300"
                   data-hide-effect="fade"
                   data-delay="600"
                   >
                   You Need Safe Storage Services? We got you covered!
                </p>
            </div><!-- .ms-slide slide03 end -->


        </div><!-- #masterslider end -->

        <div class="page-content parallax parallax01 mb-70">
            <div class="container">
                <div class="row services-negative-top">
                    <div class="col-md-4 col-sm-4">
                        <div class="service-feature-box">
                            <div class="service-media">
                                <img src="img/pics/img01.jpg" alt="Trucking"/>

                                <a href="haulage-frieght.php" class="read-more02">
                                    <span>
                                        Read more
                                        <i class="fa fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div><!-- .service-media end -->

                            <div class="service-body">
                                <div class="custom-heading">
                                    <h4>HAULAGE & FREIGHT <br>SERVICES</h4>
                                </div><!-- .custom-heading end -->

                                <p>
                                    GoldPark Logistics Limited has consistently
                                    provided the highest quality contract
                                     haulage services to our clients, business partners and industries
                                     across Nigeria.
                                     <br>
                                </p>
                            </div><!-- .service-body end -->
                        </div><!-- .service-feature-box-end -->
                    </div><!-- .col-md-4 end -->

                    <div class="col-md-4 col-sm-4">
                        <div class="service-feature-box">
                            <div class="service-media">
                                <img src="img/pics/img02.jpg" alt="Trucking"/>

                                <a href="clearing-forwarding.php" class="read-more02">
                                    <span>
                                        Read more
                                        <i class="fa fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div><!-- .service-media end -->

                            <div class="service-body">
                                <div class="custom-heading">
                                    <h4>CLEARING & FORWARDING SERVICES</h4>
                                </div><!-- .custom-heading end -->

                                <p>
                                We specialize in clearing and forwarding services
                                for our clients acting as an agent for their import
                                and export shipments. We are licensed to do business
                                as Customs Agents in Nigeria.
                                </p>
                            </div><!-- .service-body end -->
                        </div><!-- .service-feature-box-end -->
                    </div><!-- .col-md-4 end -->

                    <div class="col-md-4 col-sm-4">
                        <div class="service-feature-box">
                            <div class="service-media">
                                <img src="img/pics/img03.jpg" alt="Trucking"/>

                                <a href="warehousing.php" class="read-more02">
                                    <span>
                                        Read more
                                        <i class="fa fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div><!-- .service-media end -->

                            <div class="service-body">
                                <div class="custom-heading">
                                    <h4>WAREHOUSING <br>SERVICES</h4>
                                </div><!-- .custom-heading end -->

                                <p>
                                We offer cost effective storage services to
                                 several clients across different sectors. Our
                                  warehousing offerings are managed by experienced and
                                   dedicated staff.
                                </p>
                            </div><!-- .service-body end -->
                        </div><!-- .service-feature-box-end -->
                    </div><!-- .col-md-4 end -->
                </div><!-- .row end -->

                <div class="row">
                <p id="Our-history"></p>
                    <div class="col-md-12">
                        <a href="haulage-frieght.php" class="btn btn-big btn-yellow btn-centered">
                            <span>
                                view details
                            </span>
                        </a>
                    </div><!-- .col-md-12 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </div><!-- .page-content end -->

        <div class="whatsapp-chat">
          <a href="https://wa.me/2348160278321" target="blank">
          <div class="lineup">
            <img class="whats-image" src="img/whatsapp.png" alt="">

          </div>
          <div class="lineup">
            <p class="chat-bg" ><strong>Chat on whatsapp</strong></p>
          </div>
          </a>

        </div>


        <div class="page-content col-centered">
            <div class="container" >
            <div class="col-md-10 col-xs-offset-1">
            <div class="custom-heading">
                <h2>our history</h2>
            </div>

                <p>
                        GoldPark Logistics Limited (GPL) is a leading provider of logistics,
                        shipping, warehousing, and supply chains solutions. GPL was founded
                        in 2017 and has its headquarters in Lagos, Nigeria. We are licensed
                        by the Nigerian Customs Service and the Nigerian Port Authority to
                        provide Import and Export Clearing services, and cargo handling operations
                        in all Nigerian Ports.</p> <p>We offer unparalleled transportation,
                        distribution, customs clearing, freight forwarding and storage services
                        that are tailored to fit our customers’ needs in a wide range of industries. Our
                        dedicated team have decades of experience in haulage, port operations,
                        customs clearing procedures, international shipping, trade laws, amongst
                        other expertise.
                        <hr>
                        <div>
                        <div class="col-md-12">
                        <div class="custom-headinglow02">
                            <h1>Our Vision</h1>
                        </div>
                        <p style="text-align:center">To be the provider of choice for our customers’ logistics, shipping,<br> Customs Clearing
                            and Forwarding needs,
                             and a model of excellence for the Supply Chain industry.</p>

                    </div>
                    <br>
                    <div class="col-md-12">
                        <div class="custom-headinglow02">
                            <h1>Our Mission</h1>
                        </div>
                        <p style="text-align:center">We strive to provide superior logistics and shipping services
                         through excellent planning, implementation, and control of the<br> physical movement of goods
                          from source to destination to meet our customers’ needs. Our operating philosophy<br> is based
                          on maintaining the highest level of quality in
                        the services we provide in the most efficient manner possible.</p>

                    </div>
                        </div>
                </p>



                <br><br><br><br><br><br><br><br><br><br><br><br>


            </div>









                <div class="row">

                    <div class="col-md-12">
                        <div class="custom-heading02">
                            <h2>Why Choose Us</h2>
                            <p>
                            We offer exceptional services
                            </p>
                        </div><!-- .custom-heading02 end -->
                    </div><!-- .col-md-12 end -->
                </div><!-- .row end -->
                <div class="row mb-30">
                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/pi-cargo-1.svg" alt="checklist icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Competitve Rates</h3>

                                <p>
                                We offer the most cost-effective logistics services
                                at competitive rates.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->

                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/integrity.svg" alt="globe icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Integrity</h3>

                                <p>
                                We conduct our business ethically and in accordance
                                 with global best practice.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->
                </div><!-- .row.mb-30 end -->

                <div class="row mb-30">
                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/flexible.svg" alt="checklist icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Flexibility</h3>

                                <p>
                                We offer flexible logistic services customized
                                to the needs of your organization.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->

                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/expertise.svg" alt="globe icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Expertise</h3>

                                <p>
                                Our team has extensive experience in delivering logistics and international shipping services to clients
                                 in Nigeria.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->
                </div><!-- .row.mb-30 end -->

                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/reliable.svg" alt="forktruck icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Reliable and Committed</h3>

                                <p>
                                When you need us, we will always be there to support you.
                                 We are committed to delivering your cargo and support
                                 services on-time and to schedule.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->

                    <div class="col-md-6 col-sm-6">
                        <div class="service-icon-left-boxed">
                            <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                                <img src="img/svg/pi-truck-5.svg" alt="touch icon"/>
                            </div><!-- .icon-container end -->

                            <div class="service-details">
                                <h3>Your goods are safe with us</h3>

                                <p>
                                We know that your goods are important to you. Our experts are trained to
                                treat your cargo with extra care, handled safely and
                                 delivered in excellent condition.
                                </p>
                            </div><!-- .service-details end -->
                        </div><!-- .service-icon-left-boxed end -->
                    </div><!-- .col-md-6 end -->
                </div><!-- .row.mb-30 end -->
            </div><!-- .container end -->
        </div><!-- .page-content end -->

        <div class="page-content custom-bkg bkg-dark-blue column-img-bkg dark mb-70">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-md-offset-2 custom-col-padding-both">
                        <div class="custom-heading">
                            <h3>INDUSTRY SECTORS COVERAGE</h3>
                        </div><!-- .custom-heading end -->

                        <p>
                            We cover different industry sectors, from food and
                            beverage, chemical, retail, durable goods and more.
                            Check the full list.
                        </p>

                        <ul class="service-list clearfix">
                            <li>
                                <div class="icon-container">
                                    <img class="svg-white" src="img/svg/pi-cargo-box-2.svg" alt="icon"/>
                                </div><!-- .icon-container end -->

                                <p>
                                    Consumer Packaged Goods
                                </p>
                            </li>

                            <li>
                                <div class="icon-container">
                                    <img class="svg-white" src="img/svg/pi-mark-energy.svg" alt="icon"/>
                                </div><!-- .icon-container end -->

                                <p>
                                    Chemical Goods
                                </p>
                            </li>

                            <li>
                                <div class="icon-container">
                                    <img class="svg-white" src="img/svg/pi-food-beverage.svg" alt="icon"/>
                                </div><!-- .icon-container end -->

                                <p>
                                    Food and Beverage
                                </p>
                            </li>

                            <li>
                                <div class="icon-container">
                                    <img class="svg-white" src="img/svg/pi-cargo-retail.svg" alt="icon"/>
                                </div><!-- .icon-container end -->

                                <p>
                                    Retail Goods
                                </p>
                            </li>

                            <li>
                                <div class="icon-container">
                                    <img class="svg-white" src="img/svg/pi-truck-8.svg" alt="icon"/>
                                </div><!-- .icon-container end -->

                                <p>
                                    Energy, Oil and Gas
                                </p>
                            </li>
                        </ul><!-- .service-list end -->
                    </div><!-- .col-md-6 end -->

                    <div class="col-md-6 img-bkg01">

                        <div></div>
                    </div>

                </div><!-- .row end -->
            </div><!-- .container end -->
        </div><!-- .page-content.bkg-dark-blue end -->



        <div class="page-content">
            <div class="container">
            <div class="col-md-12 col-xs-offset-5"">
            <div class="custom-heading">
                            <h3>our clients</h3>
                        </div><!-- .custom-heading end --></div></div></div>


        <div class="page-content custom-bkg bkg-grey">
            <div class="container">
            <div class="row">



                    <div class="col-md-12">

                        <div class="carousel-container">
                            <div id="client-carousel" class="owl-carousel owl-carousel-navigation">
                                <div class="owl-item"><img src="img/pics/client01.png" alt=""/></div>
                                <div class="owl-item"><img src="img/pics/client02.png" alt=""/></div>
                                <div class="owl-item"><img src="img/pics/client03.png" alt=""/></div>
                                <div class="owl-item"><img src="img/pics/client04.png" alt=""/></div>
                                <div class="owl-item"><img src="img/pics/client05.png" alt=""/></div>
                                <div class="owl-item"><img src="img/pics/client06.png" alt=""/></div>
                            </div><!-- .owl-carousel.owl-carousel-navigation end -->
                        </div><!-- .carousel-container end -->
                    </div><!-- .col-md-12 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </div><!-- .page-content end -->

        <?php
    include("include/footer.php");
?>
